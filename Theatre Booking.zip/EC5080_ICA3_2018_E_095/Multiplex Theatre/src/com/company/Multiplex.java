package com.company;

/**
 *
 * @author 2018/E/095 Praveen
 */

import datechooser.beans.DateChooserCombo;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class Multiplex extends JFrame  {

    private JPanel MOVIEHALL;

    private JButton s1;
    private JButton s2;
    private JButton s3;
    private JButton s4;
    private JButton s5;
    private JButton s6;
    private JButton s7;
    private JButton s8;
    private JButton s9;
    private JButton s10;
    private JButton s20;
    private JButton s40;
    private JButton s50;
    private JButton s60;
    private JButton s70;
    private JButton s80;
    private JButton s11;
    private JButton s21;
    private JButton s31;
    private JButton s41;
    private JButton s51;
    private JButton s61;
    private JButton s71;
    private JButton s12;
    private JButton s22;
    private JButton s32;
    private JButton s42;
    private JButton s52;
    private JButton s62;
    private JButton s72;
    private JButton s83;
    private JButton s73;
    private JButton s63;
    private JButton s53;
    private JButton s43;
    private JButton s33;
    private JButton s23;
    private JButton s13;
    private JButton s14;
    private JButton s24;
    private JButton s34;
    private JButton s44;
    private JButton s54;
    private JButton s64;
    private JButton s74;
    private JButton s84;
    private JButton s85;
    private JButton s75;
    private JButton s65;
    private JButton s55;
    private JButton s45;
    private JButton s35;
    private JButton s25;
    private JButton s15;
    private JButton s16;
    private JButton s26;
    private JButton s36;
    private JButton s46;
    private JButton s56;
    private JButton s66;
    private JButton s76;
    private JButton s86;
    private JButton s87;
    private JButton s77;
    private JButton s67;
    private JButton s57;
    private JButton s47;
    private JButton s37;
    private JButton s27;
    private JButton s17;
    private JButton s18;
    private JButton s28;
    private JButton s38;
    private JButton s48;
    private JButton s58;
    private JButton s68;
    private JButton s78;
    private JButton s88;
    private JButton s79;
    private JButton s69;
    private JButton s59;
    private JButton s49;
    private JButton s39;
    private JButton s19;

    private JLabel Film;
    private JTextField Filmname;
    private JLabel total;
    private JLabel seats;

    private DateChooserCombo date; //choose date easily

    private JLabel TotalLabel;
    private JLabel DateLabel;
    private JLabel SeatsLabel;
    private JButton booking;
    private JLabel Available;
    private JLabel sold;
    private JTextField available;
    private JTextField Sold;
    private JTextField selected;
    private JButton screen;
    private JLabel TicketsLabel;
    private JLabel ticketCount;
    private JLabel Time;
    private JSpinner hour;
    private JSpinner minutes;


    private String key = " ";
    private String times;
    private int countSelectedSeat;
    private ArrayList<String> bookingSeatArray = new ArrayList<>();


    private int Rtotal(ArrayList arr) //Total Price after remove some seat.
    {
        int total = 0;

        for (Object o : arr) {

            if (o.equals("J3")||o.equals("J4")||o.equals("J5")||o.equals("J6")||o.equals("J7")||o.equals("J8")) {
                total = total + 20;
            } else {
                total = total + 12;
            }

        }
        return total;
    }


    private int Atotal(ArrayList arr) //Total Price when add some seat
    {
        int total = 0;
        for (Object o : arr) {

            if (o.equals("J3")||o.equals("J4")||o.equals("J5")||o.equals("J6")||o.equals("J7")||o.equals("J8")) {
                total = total + 20;
            } else {
                total = total + 12;
            }

        }
      return total;
    }

    //Select certain seat
    private void selectedbutton(JButton btn , String loc)
    {
        if(btn.getBackground() !=  Color.green ){

            key =loc+btn.getText() ;
            bookingSeatArray.add(key);

            //selected position
            seats.setText(String.valueOf(bookingSeatArray));

            //total price
            total.setText(Integer.toString(Atotal(bookingSeatArray)) + " $");

            btn.setBackground(Color.green);

            //number of selected seats
            countSelectedSeat++;
            ticketCount.setText(Integer.toString(countSelectedSeat));

            times = String.valueOf(hour.getValue())+":"+String.valueOf(minutes.getValue());
        }
        else if(btn.getBackground() ==  Color.green )
        {

            key =loc+btn.getText() ;
            bookingSeatArray.remove(key);

            //selected position
            seats.setText(String.valueOf(bookingSeatArray));

            //total price
            total.setText(Integer.toString(Rtotal(bookingSeatArray))+" $");

            //number of selected seats
            countSelectedSeat--;
            ticketCount.setText(Integer.toString(countSelectedSeat));
            btn.setBackground(new Color(183,183,183));

            times = String.valueOf(hour.getValue())+":"+String.valueOf(minutes.getValue());

        }

    }

    //Booking
    private void bookedbutton(JButton btn)
    {
        if (btn.getBackground() ==  Color.green)
        {
            if (countSelectedSeat != 0)
            {
                Movieticket movieticket = new Movieticket(Filmname,ticketCount,total,seats, date,times);
            }

            btn.setForeground(Color.BLUE);
            btn.setBackground(Color.red);
            btn.setEnabled(false);
            countSelectedSeat = 0;
            ticketCount.setText(Integer.toString(countSelectedSeat));
            bookingSeatArray.clear();
            seats.setText(String.valueOf(bookingSeatArray));
            total.setText(Integer.toString(Rtotal(bookingSeatArray))+" $");

        }

    }


    public Multiplex(String s)
    {
        ImageIcon img1 = new ImageIcon("./pics/popcornlogo.png");
        Image i1 = img1.getImage();
        Image newImg = i1.getScaledInstance(120,120, Image.SCALE_FAST);
        img1 = new ImageIcon(newImg);
        this.setIconImage(img1.getImage());

        Filmname.setText(s);

        this.add(MOVIEHALL);

        this.setSize(1300,620);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);

        ButtonGroup b = new ButtonGroup();
        b.add(s1);
        b.add(s2);


        s1.addActionListener(e -> selectedbutton(s1,"A"));
        s2.addActionListener(e -> selectedbutton(s2,"A"));
        s3.addActionListener(e -> selectedbutton(s3,"A"));
        s4.addActionListener(e -> selectedbutton(s4,"A"));
        s5.addActionListener(e -> selectedbutton(s5,"A"));
        s6.addActionListener(e -> selectedbutton(s6,"A"));
        s7.addActionListener(e -> selectedbutton(s7,"A"));
        s8.addActionListener(e -> selectedbutton(s8,"A"));
        s9.addActionListener(e -> selectedbutton(s9,"A"));
        s10.addActionListener(e -> selectedbutton(s10,"A"));
        s11.addActionListener(e -> selectedbutton(s11,"B"));
        s12.addActionListener(e -> selectedbutton(s12,"B"));
        s13.addActionListener(e -> selectedbutton(s13,"B"));
        s14.addActionListener(e -> selectedbutton(s14,"B"));
        s15.addActionListener(e -> selectedbutton(s15,"B"));
        s16.addActionListener(e -> selectedbutton(s16,"B"));
        s17.addActionListener(e -> selectedbutton(s17,"B"));
        s18.addActionListener(e -> selectedbutton(s18,"B"));
        s19.addActionListener(e -> selectedbutton(s19,"B"));
        s20.addActionListener(e -> selectedbutton(s20,"B"));
        s21.addActionListener(e -> selectedbutton(s21,"D"));
        s22.addActionListener(e -> selectedbutton(s22,"D"));
        s23.addActionListener(e -> selectedbutton(s23,"D"));
        s24.addActionListener(e -> selectedbutton(s24,"D"));
        s25.addActionListener(e -> selectedbutton(s25,"D"));
        s26.addActionListener(e -> selectedbutton(s26,"D"));
        s27.addActionListener(e -> selectedbutton(s27,"D"));
        s28.addActionListener(e -> selectedbutton(s28,"D"));
        s31.addActionListener(e -> selectedbutton(s31,"E"));
        s32.addActionListener(e -> selectedbutton(s32,"E"));
        s33.addActionListener(e -> selectedbutton(s33,"E"));
        s34.addActionListener(e -> selectedbutton(s34,"E"));
        s35.addActionListener(e -> selectedbutton(s35,"E"));
        s36.addActionListener(e -> selectedbutton(s36,"E"));
        s37.addActionListener(e -> selectedbutton(s37,"E"));
        s38.addActionListener(e -> selectedbutton(s38,"E"));
        s39.addActionListener(e -> selectedbutton(s39,"E"));
        s40.addActionListener(e -> selectedbutton(s40,"E"));
        s41.addActionListener(e -> selectedbutton(s41,"F"));
        s42.addActionListener(e -> selectedbutton(s42,"F"));
        s43.addActionListener(e -> selectedbutton(s43,"F"));
        s44.addActionListener(e -> selectedbutton(s44,"F"));
        s45.addActionListener(e -> selectedbutton(s45,"F"));
        s46.addActionListener(e -> selectedbutton(s46,"F"));
        s47.addActionListener(e -> selectedbutton(s47,"F"));
        s48.addActionListener(e -> selectedbutton(s48,"F"));
        s49.addActionListener(e -> selectedbutton(s49,"F"));
        s50.addActionListener(e -> selectedbutton(s50,"F"));
        s51.addActionListener(e -> selectedbutton(s51,"G"));
        s52.addActionListener(e -> selectedbutton(s52,"G"));
        s52.addActionListener(e -> selectedbutton(s52,"G"));
        s53.addActionListener(e -> selectedbutton(s53,"G"));
        s54.addActionListener(e -> selectedbutton(s54,"G"));
        s55.addActionListener(e -> selectedbutton(s55,"G"));
        s56.addActionListener(e -> selectedbutton(s56,"G"));
        s57.addActionListener(e -> selectedbutton(s57,"G"));
        s58.addActionListener(e -> selectedbutton(s58,"G"));
        s59.addActionListener(e -> selectedbutton(s59,"G"));
        s60.addActionListener(e -> selectedbutton(s60,"G"));
        s61.addActionListener(e -> selectedbutton(s61,"H"));
        s62.addActionListener(e -> selectedbutton(s62,"H"));
        s63.addActionListener(e -> selectedbutton(s63,"H"));
        s64.addActionListener(e -> selectedbutton(s64,"H"));
        s65.addActionListener(e -> selectedbutton(s65,"H"));
        s66.addActionListener(e -> selectedbutton(s66,"H"));
        s67.addActionListener(e -> selectedbutton(s67,"H"));
        s68.addActionListener(e -> selectedbutton(s68,"H"));
        s69.addActionListener(e -> selectedbutton(s69,"H"));
        s70.addActionListener(e -> selectedbutton(s70,"H"));
        s71.addActionListener(e -> selectedbutton(s71,"I"));
        s72.addActionListener(e -> selectedbutton(s72,"I"));
        s73.addActionListener(e -> selectedbutton(s73,"I"));
        s74.addActionListener(e -> selectedbutton(s74,"I"));
        s75.addActionListener(e -> selectedbutton(s75,"I"));
        s76.addActionListener(e -> selectedbutton(s76,"I"));
        s77.addActionListener(e -> selectedbutton(s77,"I"));
        s78.addActionListener(e -> selectedbutton(s78,"I"));
        s79.addActionListener(e -> selectedbutton(s79,"I"));
        s80.addActionListener(e -> selectedbutton(s80,"I"));
        s83.addActionListener(e -> selectedbutton(s83,"J"));
        s84.addActionListener(e -> selectedbutton(s84,"J"));
        s85.addActionListener(e -> selectedbutton(s85,"J"));
        s86.addActionListener(e -> selectedbutton(s86,"J"));
        s87.addActionListener(e -> selectedbutton(s87,"J"));
        s88.addActionListener(e -> selectedbutton(s88,"J"));

        booking.addActionListener(e -> {

            bookedbutton(s1);
            bookedbutton(s2);
            bookedbutton(s3);
            bookedbutton(s4);
            bookedbutton(s5);
            bookedbutton(s6);
            bookedbutton(s7);
            bookedbutton(s8);
            bookedbutton(s9);
            bookedbutton(s10);
            bookedbutton(s11);
            bookedbutton(s12);
            bookedbutton(s13);
            bookedbutton(s14);
            bookedbutton(s15);
            bookedbutton(s16);
            bookedbutton(s17);
            bookedbutton(s18);
            bookedbutton(s19);
            bookedbutton(s20);
            bookedbutton(s21);
            bookedbutton(s22);
            bookedbutton(s23);
            bookedbutton(s24);
            bookedbutton(s25);
            bookedbutton(s26);
            bookedbutton(s27);
            bookedbutton(s28);
            bookedbutton(s31);
            bookedbutton(s32);
            bookedbutton(s33);
            bookedbutton(s34);
            bookedbutton(s35);
            bookedbutton(s36);
            bookedbutton(s37);
            bookedbutton(s38);
            bookedbutton(s39);
            bookedbutton(s40);
            bookedbutton(s41);
            bookedbutton(s42);
            bookedbutton(s43);
            bookedbutton(s44);
            bookedbutton(s45);
            bookedbutton(s46);
            bookedbutton(s47);
            bookedbutton(s48);
            bookedbutton(s49);
            bookedbutton(s50);
            bookedbutton(s51);
            bookedbutton(s52);
            bookedbutton(s53);
            bookedbutton(s54);
            bookedbutton(s55);
            bookedbutton(s56);
            bookedbutton(s57);
            bookedbutton(s58);
            bookedbutton(s59);
            bookedbutton(s60);
            bookedbutton(s61);
            bookedbutton(s62);
            bookedbutton(s63);
            bookedbutton(s64);
            bookedbutton(s65);
            bookedbutton(s66);
            bookedbutton(s67);
            bookedbutton(s68);
            bookedbutton(s69);
            bookedbutton(s70);
            bookedbutton(s71);
            bookedbutton(s72);
            bookedbutton(s73);
            bookedbutton(s74);
            bookedbutton(s75);
            bookedbutton(s76);
            bookedbutton(s77);
            bookedbutton(s78);
            bookedbutton(s79);
            bookedbutton(s80);
            bookedbutton(s83);
            bookedbutton(s84);
            bookedbutton(s85);
            bookedbutton(s86);
            bookedbutton(s87);
            bookedbutton(s88);

        }
        );

        screen.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                FRAME m = new FRAME();
            }
        });
    }

}
