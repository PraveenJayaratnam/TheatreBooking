package com.company;

/**
 *
 * @author 2018/E/095 Praveen
 */

import datechooser.beans.DateChooserCombo;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

public class Movieticket extends JFrame{

    private JLabel Filmname;
    private JLabel Filmdate;
    private JLabel Ticketcount;
    private JLabel Totalprice;
    private JLabel seatesbooking;
    private JPanel TicketCard;
    private JButton Download;
    private JButton cancel;
    private JLabel time;

    Movieticket(JTextField movie, JLabel ticket, JLabel total, JLabel seats , DateChooserCombo date , String times){

        this.add(TicketCard);
        ImageIcon img1 = new ImageIcon("./pics/ticket.jpg");
        Image i1 = img1.getImage();
        Image newImg = i1.getScaledInstance(120,120, Image.SCALE_FAST);
        img1 = new ImageIcon(newImg);
        this.setIconImage(img1.getImage());


        this.setSize(400,360);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);


        time.setText(times);
        Filmname.setText(String.valueOf(movie.getText()));
        Filmdate.setText(String.valueOf(date.getText()));
        Ticketcount.setText(String.valueOf(ticket.getText()));
        Totalprice.setText(String.valueOf(total.getText()));
        seatesbooking.setText(String.valueOf(seats.getText()));

        Download.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFileChooser fileChooser = new JFileChooser();

                int r = fileChooser.showSaveDialog(null);


                if (r == JFileChooser.APPROVE_OPTION){
                    File file = new File(fileChooser.getSelectedFile().getAbsolutePath());
                    System.out.println(file);
                }

            }
        });
        cancel.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Multiplex m = new Multiplex( Filmname.getText());
            }
        });
    }
}
