package com.company;

/**
 *
 * @author 2018/E/095 Praveen
 */

import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

public class FRAME extends JFrame implements MouseListener {
    private JPanel hp; //head panel
    private JPanel tp; //tail panel
    private JLabel hl; //head label
    private JLabel scr1; //screen1
    private JLabel scr2; //screen2
    private JLabel scr3; //screen2
    private JLabel scr4; //screen2
    private JLabel scr5; //screen2
    private JLabel scr6; //screen2

    Border border = BorderFactory.createLineBorder(new Color(20, 161, 196), 2); //border colour and thickness


    private void designborder(JLabel label) {
        label.setBorder(border);
        label.setOpaque(true);  //display background colour
        label.setHorizontalTextPosition(JLabel.CENTER); //set text left,centre,right
        label.setVerticalTextPosition(JLabel.BOTTOM); //set text top,centre,bottom
        label.setHorizontalAlignment(JLabel.CENTER); // horizontal text and logo position within label
        label.setVerticalAlignment(JLabel.CENTER);  // vertical text position within label

        label.setFont(new Font("Stencil",Font.PLAIN,24)); //set font of text
    }


    FRAME() {
        hp = new JPanel(); //head panel
        tp = new JPanel(); //tail panel
        this.setResizable(false); // prevent frame from being resized

        ImageIcon img = new ImageIcon("./pics/popcornlogo.png"); //create image icon
        Image i = img.getImage();
        Image n = i.getScaledInstance(120, 120, Image.SCALE_FAST); //scale the logo
        img = new ImageIcon(n);
        this.setIconImage(img.getImage()); //change icon of this from default java logo

        ImageIcon img1 = new ImageIcon("./pics/dredd.png"); //create movie logo
        Image i1 = img1.getImage();
        Image newImg = i1.getScaledInstance(200, 220, Image.SCALE_FAST); //scale movie logo
        img1 = new ImageIcon(newImg); //put movie logo

        ImageIcon img2 = new ImageIcon("./pics/MortalKombat.png"); //create movie logo
        Image i2 = img2.getImage();
        Image newImg2 = i2.getScaledInstance(200, 220, Image.SCALE_FAST); //scale movie logo
        img2 = new ImageIcon(newImg2); //put movie logo

        ImageIcon img3 = new ImageIcon("./pics/starwars.jpeg"); //create movie logo
        Image i3 = img3.getImage();
        Image newImg3 = i3.getScaledInstance(200, 220, Image.SCALE_FAST); //scale movie logo
        img3 = new ImageIcon(newImg3); //put movie logo

        ImageIcon img4 = new ImageIcon("./pics/Taken3.jpg"); //create movie logo
        Image i4 = img4.getImage();
        Image newImg4 = i4.getScaledInstance(200, 220, Image.SCALE_FAST); //scale movie logo
        img4 = new ImageIcon(newImg4); //put movie logo

        ImageIcon img5 = new ImageIcon("./pics/Tolkien.jpg"); //create movie logo
        Image i5 = img5.getImage();
        Image newImg5 = i5.getScaledInstance(200, 220, Image.SCALE_FAST); //scale movie logo
        img5 = new ImageIcon(newImg5); //put movie logo

        ImageIcon img6 = new ImageIcon("./pics/Werewolves.jpg"); //create movie logo
        Image i6 = img6.getImage();
        Image newImg6 = i6.getScaledInstance(200, 220, Image.SCALE_FAST); //scale movie logo
        img6 = new ImageIcon(newImg6); //put movie logo


        hl = new JLabel();

        hl.setText("Multiplex Theatre Seat Booking");
        hp.setBackground(new Color(207, 212, 213));
        designborder(hl);
        hl.setFont(new Font("Stencil",Font.ITALIC,30));

        scr1 = new JLabel(img1);
        scr1.setText("DREDD3");
        designborder(scr1);

        scr2 = new JLabel(img2);
        scr2.setText("MORTAL COMBAT");
        designborder(scr2);

        scr3 = new JLabel(img3);
        scr3.setText("STARWARS");
        designborder(scr3);

        scr4 = new JLabel(img4);
        scr4.setText("TAKEN3");
        designborder(scr4);

        scr5 = new JLabel(img5);
        scr5.setText("TOLKIEN");
        designborder(scr5);

        scr6 = new JLabel(img6);
        scr6.setText("WEREWOLVES");
        designborder(scr6);

        hp.add(hl);
        tp.add(scr1);
        tp.add(scr2);
        tp.add(scr3);
        tp.add(scr4);
        tp.add(scr5);
        tp.add(scr6);

        scr1.addMouseListener(this);
        scr2.addMouseListener(this);
        scr3.addMouseListener(this);
        scr4.addMouseListener(this);
        scr5.addMouseListener(this);
        scr6.addMouseListener(this);

        tp.setSize(720,1080 );
        tp.setLayout(new GridLayout(2, 3));


        this.add(hp);
        this.add(tp);

        this.setLayout(new FlowLayout());
        this.setSize(650, 600);

        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);
    }

    @Override
    public void mouseClicked(MouseEvent e) {

    }

    @Override
    public void mousePressed(MouseEvent e) {

    }

    @Override
    public void mouseReleased(MouseEvent e) {
        if (e.getSource() == scr1) {
            Multiplex m = new Multiplex(scr1.getText());
        }
        if (e.getSource() == scr2) {
            Multiplex m = new Multiplex(scr2.getText());
        }
        if (e.getSource() == scr3) {
            Multiplex m = new Multiplex(scr3.getText());
        }
        if (e.getSource() == scr4) {
            Multiplex m = new Multiplex(scr4.getText());
        }
        if (e.getSource() == scr5) {
            Multiplex m = new Multiplex(scr5.getText());
        }
        if (e.getSource() == scr6) {
            Multiplex m = new Multiplex(scr6.getText());
        }

    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }
}
