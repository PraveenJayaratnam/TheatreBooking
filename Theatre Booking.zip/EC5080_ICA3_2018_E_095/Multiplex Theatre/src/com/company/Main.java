package com.company;

/**
 *
 * @author 2018/E/095 Praveen
 */

//CLICK ON THE MOVIE YOU WANT AND RELEASE TO ENTER SEAT BOOKING

import java.io.IOException;

public class Main {

    public static void main(String[] args) throws IOException {
        FRAME f = new FRAME();
    }
}
